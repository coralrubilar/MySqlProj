MySQL with C++
==============

Steps:

1. Change database details in database-detail.h file.

2. Download this code
    $ git clone https://github.com/megha55/mysql-with-cpp.git

3. To run example
    $ make

4. For installing MySQL Connector for C++
    $ make install
