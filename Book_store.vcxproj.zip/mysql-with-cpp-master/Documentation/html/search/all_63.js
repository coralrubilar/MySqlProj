var searchData=
[
  ['connect',['connect',['../classMySQL.html#a56a2a9159f6d46d8b3bd648e1f08e2b1',1,'MySQL']]]
];
