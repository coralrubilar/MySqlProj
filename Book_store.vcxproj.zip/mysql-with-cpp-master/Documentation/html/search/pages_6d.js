var searchData=
[
  ['mysql_20connectivity_20with_20c_2b_2b',['MySQL Connectivity with C++',['../index.html',1,'']]],
  ['mysql_20with_20c_2b_2b',['MySQL with C++',['../md_README.html',1,'']]]
];
