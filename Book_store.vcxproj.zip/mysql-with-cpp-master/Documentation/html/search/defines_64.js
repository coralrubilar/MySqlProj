var searchData=
[
  ['database',['DATABASE',['../database-detail_8h.html#a39dc88d73783e112dbfcf98adbdbefa6',1,'database-detail.h']]]
];
