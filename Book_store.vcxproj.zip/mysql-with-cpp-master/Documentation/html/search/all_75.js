var searchData=
[
  ['user',['USER',['../database-detail_8h.html#a8bfbbf31b7d3c07215440d18a064b7f4',1,'database-detail.h']]]
];
